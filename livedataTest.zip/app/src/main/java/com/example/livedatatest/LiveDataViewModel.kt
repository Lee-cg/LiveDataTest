package com.example.livedatatest

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class LiveDataViewModel: ViewModel() {

    //뷰모델에 LiveData 선언
    val mLiveData: MutableLiveData<String> by lazy{
        MutableLiveData<String>()
    }
}