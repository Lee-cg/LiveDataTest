package com.example.livedatatest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.livedatatest.databinding.ActivityMainBinding

// ViewBinding, LiveData, ViewModel을 사용한 예제
// The Beatles 버튼을 클릭할때 마다 멤버의 이름이 차례대로 나오는 예제
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding //뷰 바인딩 클래스 선언
    private lateinit var mViewModel: LiveDataViewModel // 뷰모델 선언

    private var num = 0;
    private val memberName = listOf("John" ,"Paul", "George", "Ringo")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater) // 뷰 바인딩 클래스 인플레이트
        val view = binding.root
        setContentView(view)

        //뷰모델 객체 얻기
        mViewModel = ViewModelProvider(this,ViewModelProvider.NewInstanceFactory())
            .get(LiveDataViewModel::class.java)

        // 옵저버 클래스 선언 및 정의
        val memberObserver = Observer<String> { newName ->
            binding.textTest.text = newName
        }

        // 위에서 정의한 옵저버 클래스를 LiveData에 장착
        // (Observer 객체가 LiveData 객체를 구독하여 변경사항의 알림을 받는다.)
        mViewModel.mLiveData.observe(this, memberObserver)

        // 버튼 클릭 리스너 등록
        // 버튼을 클릭할때 마다 mLiveData가 가지고 있는 String 값을 바꿔주고 있다.
        // String 값이 바뀔때 마다 memberObserver의 onChanged 메소드가 콜백으로 호출된다.
        binding.btnChange.setOnClickListener {
            mViewModel.mLiveData.value = memberName[num++%4]
        }
    }
}